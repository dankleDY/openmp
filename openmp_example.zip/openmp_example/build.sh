#! /bin/bash

gcc -fopenmp -o test test.c -lrt
